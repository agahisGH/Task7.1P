package com.example.task71p;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.example.task71p.data.DatabaseHelper;

public class MainActivity extends AppCompatActivity {

    Button buttonCreate;
    Button buttonShow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonCreate = findViewById(R.id.buttonCreate);
        buttonShow = findViewById(R.id.buttonShow);

        buttonCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCreate = new Intent(MainActivity.this, CreateActivity.class);
                startActivity(intentCreate);
            }
        });

        buttonShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentShow = new Intent(MainActivity.this, FindActivity.class);
                startActivity(intentShow);


            }
        });
    }
}
