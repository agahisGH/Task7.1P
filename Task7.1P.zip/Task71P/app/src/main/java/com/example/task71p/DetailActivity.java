package com.example.task71p;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.task71p.data.DatabaseHelper;

public class DetailActivity extends AppCompatActivity {

    TextView details;
    Button remove;

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        details = findViewById(R.id.textViewDetails);
        remove = findViewById(R.id.buttonRemove);

        db = new DatabaseHelper(this);

        Intent intent = getIntent();
        Integer advert_id = intent.getIntExtra("advert_id", 0);
        String name = intent.getStringExtra("name");
        String phone = intent.getStringExtra("phone");
        String description = intent.getStringExtra("description");
        String date = intent.getStringExtra("date");
        String location = intent.getStringExtra("location");

        details.setText("Name: " + name + "\nPhone: " + phone + "\nDescription: " + description + "\nDate: " + date + "\nLocation: " + location);

        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.removeAdvert(Long.valueOf(advert_id));
                Intent intent = new Intent(getApplicationContext(), FindActivity.class);
                startActivity(intent);
            }
        });
    }
}
