package com.example.task71p;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.task71p.data.DatabaseHelper;
import com.example.task71p.model.User;

public class CreateActivity extends AppCompatActivity {

    DatabaseHelper db;

    RadioGroup radioGroup;
    RadioButton radioButton;

    EditText name;
    EditText phone;
    EditText description;
    EditText date;
    EditText location;

    Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        radioGroup = findViewById(R.id.radioGroup);

        name = findViewById(R.id.editTextName);
        phone = findViewById(R.id.editTextPhone);
        description = findViewById(R.id.editTextDescription);
        date = findViewById(R.id.editTextDate);
        location = findViewById(R.id.editTextLocation);

        saveButton = findViewById(R.id.buttonSave);

        db = new DatabaseHelper(this);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String stype = radioButton.getText().toString();
                String sname = name.getText().toString();
                String sphone = phone.getText().toString();
                String sdescription = description.getText().toString();
                String sdate = date.getText().toString();
                String slocation = location.getText().toString();

                //add check for radio buttons...

                if (sname.isEmpty() || sphone.isEmpty() || sdescription.isEmpty() || sdate.isEmpty() || slocation.isEmpty())
                {
                    Toast.makeText(CreateActivity.this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    long result = db.insertAdvert(new User(stype, sname, sphone, sdescription, sdate, slocation));

                    if (result > 0)
                    {
                        Toast.makeText(CreateActivity.this, "Success", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(CreateActivity.this, "Fail", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public void checkRadioButton(View v)
    {
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);

        Toast.makeText(this, "Selected Radio Button: " + radioButton.getText(), Toast.LENGTH_SHORT).show();
    }
}
